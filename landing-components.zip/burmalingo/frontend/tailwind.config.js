/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C8941A', light: '#E0A820', pale: '#FDF3DC' },
        forest: { DEFAULT: '#1B4332', mid: '#2D6A4F', pale: '#EAF5EE' },
        cream: '#FAF6EE',
        bark: { DEFAULT: '#1C0E05', mid: '#5C3D1E', light: '#8B6343' },
        border: '#E8D5B0',
        card: '#FFFDF7',
        ruby: { DEFAULT: '#8B1A1A', pale: '#FFF0F0' },
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease both',
        'fade-up-2': 'fadeUp 0.6s 0.15s ease both',
        'fade-up-3': 'fadeUp 0.6s 0.3s ease both',
        'float': 'float 3.5s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(18px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-7px)' },
        },
      },
    },
  },
  plugins: [],
}

interface CTAProps {
  onDemo: () => void
}

export function CTABanner({ onDemo }: CTAProps) {
  return (
    <div className="bg-forest py-20 px-7 text-center">
      <h2 className="font-serif text-white text-4xl font-extrabold mb-4">
        Try a live lesson now
      </h2>
      <p className="text-white/65 text-sm mb-8">
        No signup. Experience vocabulary cards, translation practice, and writing feedback live.
      </p>
      <button onClick={onDemo} className="btn-gold px-9 py-4 text-base">
        Start Demo Lesson →
      </button>
    </div>
  )
}

export function Footer() {
  return (
    <footer className="bg-bark py-9 px-7 text-center">
      <div className="font-serif text-gold-light text-xl font-bold mb-1.5">BurmaLingo</div>
      <p className="text-white/40 text-xs">
        Built by a Burmese immigrant, for Burmese learners worldwide.
      </p>
    </footer>
  )
}

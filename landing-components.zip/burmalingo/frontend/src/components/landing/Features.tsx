const features = [
  {
    icon: '📖',
    title: 'Reading Comprehension',
    desc: 'Graded passages from Level 5 to 10. Vocabulary in context, comprehension questions, key phrase breakdowns. Free: 3 passages per 2 weeks.',
    badge: null,
  },
  {
    icon: '✍️',
    title: 'Writing Practice',
    desc: 'Given a topic, write your response in English. AI grades your grammar, structure, and vocabulary — and shows a model answer. Free: 3 submissions per 2 weeks, AI feedback locked.',
    badge: 'Pro — AI feedback',
  },
  {
    icon: '🔄',
    title: 'Translation Practice',
    desc: 'Given a Burmese sentence, write it in English. AI evaluates your answer, shows the most natural version, and explains what to improve. Free: 3 per week.',
    badge: 'Pro — AI feedback',
  },
  {
    icon: '🧠',
    title: 'Vocabulary (SM-2)',
    desc: 'Spaced repetition algorithm implemented from scratch. Reviews scheduled at exactly the moment you are about to forget. Free: 10 cards per week.',
    badge: null,
  },
  {
    icon: '🔈',
    title: 'Listening Practice',
    desc: 'Pre-generated native audio, stored permanently. Listen and answer comprehension questions to train your ear for real English. Free: 3 per 2 weeks.',
    badge: null,
  },
  {
    icon: '🎙️',
    title: 'Speaking Practice',
    desc: 'Record yourself speaking. Web Speech API transcribes your audio, backend compares to the correct answer, AI gives pronunciation and accuracy feedback.',
    badge: 'Pro only',
  },
]

export default function Features() {
  return (
    <section className="py-20 px-7 max-w-5xl mx-auto">
      <div className="text-center mb-14">
        <p className="section-label mb-3">Features</p>
        <h2 className="font-serif text-4xl font-extrabold text-bark">
          Everything you need<br />to master English
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {features.map((f) => (
          <div
            key={f.title}
            className="card p-7 hover:-translate-y-1 transition-transform duration-200 cursor-default"
          >
            <div className="text-2xl mb-3">{f.icon}</div>
            <h3 className="font-serif text-lg font-bold text-bark mb-2">{f.title}</h3>
            {f.badge && (
              <span className="inline-block text-xs bg-forest-pale text-forest-mid
                               px-2.5 py-0.5 rounded-full mb-2">
                {f.badge}
              </span>
            )}
            <p className="text-bark-light text-sm leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

interface HeroProps {
  onDemo: () => void
}

export default function Hero({ onDemo }: HeroProps) {
  const badges = [
    { icon: '📶', label: '10 levels — basic to advanced' },
    { icon: '🧠', label: 'SM-2 spaced repetition' },
    { icon: '🤖', label: 'AI grammar feedback' },
    { icon: '📖', label: 'IELTS prep included' },
  ]

  return (
    <div
      className="relative overflow-hidden text-center px-7 py-24"
      style={{ background: 'linear-gradient(165deg, #0D2B1E 0%, #1B4332 60%, #163827 100%)' }}
    >
      {/* Decorative circles */}
      <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full border border-gold/20 pointer-events-none" />
      <div className="absolute -top-8 -right-8 w-48 h-48 rounded-full border border-gold/10 pointer-events-none" />
      <div className="absolute -bottom-16 -left-16 w-64 h-64 rounded-full border border-gold/10 pointer-events-none" />

      <div className="text-5xl mb-5 animate-float">🏛️</div>

      <p className="section-label text-gold-light mb-4 animate-fade-up">
        For Burmese Speakers
      </p>

      <h1 className="font-serif text-white font-black leading-tight mb-3 animate-fade-up-2"
          style={{ fontSize: 'clamp(34px, 5.5vw, 62px)' }}>
        English. Explained<br />
        <span className="text-gold-light italic">in your language.</span>
      </h1>

      <p className="text-white/65 text-sm max-w-lg mx-auto mb-9 leading-relaxed animate-fade-up-3">
        Grammar explained in Burmese. Spaced repetition vocabulary. AI feedback on your
        writing — built by a Burmese immigrant who studied English before arriving in the US,
        and learned what real-world fluency actually takes after living it for 3 years.
      </p>

      <div className="flex gap-2.5 justify-center flex-wrap animate-fade-up-3">
        <button onClick={onDemo} className="btn-gold px-7 py-4 text-base flex items-center gap-2">
          Try It Free →
        </button>
        <button
          onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
          className="btn-ghost px-7 py-4 text-base"
        >
          How It Works
        </button>
      </div>

      <div className="flex gap-7 justify-center mt-11 flex-wrap">
        {badges.map(({ icon, label }) => (
          <div key={label} className="flex items-center gap-1.5 text-white/50 text-xs">
            <span className="text-sm">{icon}</span>
            {label}
          </div>
        ))}
      </div>
    </div>
  )
}

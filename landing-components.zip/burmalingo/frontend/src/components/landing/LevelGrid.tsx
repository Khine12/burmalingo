import { useState } from 'react'

interface Level {
  n: number
  name: string
  desc: string
  available: boolean
}

const LEVELS: Level[] = [
  { n: 1,  name: 'Starter',              desc: 'Alphabet, greetings, numbers, basic phrases',                         available: false },
  { n: 2,  name: 'Beginner I',           desc: 'Simple sentences, present tense, essential vocabulary',               available: false },
  { n: 3,  name: 'Beginner II',          desc: 'Past & future tense, common grammar patterns',                        available: false },
  { n: 4,  name: 'Elementary',           desc: 'Everyday conversations, compound sentences',                          available: false },
  { n: 5,  name: 'Intermediate I',       desc: 'Complex grammar, formal vs. informal register',                       available: true  },
  { n: 6,  name: 'Intermediate II',      desc: 'Idiomatic expressions, paragraph writing',                            available: true  },
  { n: 7,  name: 'Intermediate III',     desc: 'Academic vocabulary, essay structure, IELTS reading & writing prep',  available: true  },
  { n: 8,  name: 'Upper-Intermediate I', desc: 'Nuanced grammar, professional writing, IELTS preparation',            available: true  },
  { n: 9,  name: 'Upper-Intermediate II',desc: 'Near-fluent communication, complex argumentation',                    available: true  },
  { n: 10, name: 'Advanced',             desc: 'Professional & academic English — the realistic ceiling for self-study', available: true },
]

export default function LevelGrid() {
  const [hovered, setHovered] = useState<number | null>(null)

  return (
    <section className="py-20 px-7 max-w-5xl mx-auto">
      <div className="text-center mb-14">
        <p className="section-label mb-3">Curriculum</p>
        <h2 className="font-serif text-4xl font-extrabold text-bark mb-4">
          10 levels. One clear path.
        </h2>
        <p className="text-bark-light text-sm max-w-md mx-auto">
          From your first English sentence to professional fluency.
          No jumping around — each level builds on the last.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {LEVELS.map((lv) => (
          <div
            key={lv.n}
            onMouseEnter={() => setHovered(lv.n)}
            onMouseLeave={() => setHovered(null)}
            className={`rounded-xl border p-5 transition-all duration-200 ${
              lv.available
                ? hovered === lv.n
                  ? 'bg-forest border-forest-mid'
                  : 'bg-card border-border hover:-translate-y-0.5'
                : 'bg-cream border-border opacity-60'
            }`}
          >
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                  lv.available
                    ? hovered === lv.n ? 'bg-white/15 text-gold-light' : 'bg-gold-pale text-gold'
                    : 'bg-border text-bark-light'
                }`}>
                  {lv.n}
                </div>
                <span className={`font-serif font-bold text-sm ${
                  lv.available
                    ? hovered === lv.n ? 'text-white' : 'text-bark'
                    : 'text-bark-light'
                }`}>
                  {lv.name}
                </span>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full whitespace-nowrap ${
                !lv.available
                  ? 'bg-border text-bark-light'
                  : hovered === lv.n
                    ? 'bg-white/15 text-gold-light'
                    : 'bg-forest-pale text-forest-mid'
              }`}>
                {lv.available ? 'Available' : 'Coming soon'}
              </span>
            </div>
            <p className={`text-xs leading-relaxed ml-9 ${
              lv.available
                ? hovered === lv.n ? 'text-white/70' : 'text-bark-light'
                : 'text-bark-light'
            }`}>
              {lv.desc}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}

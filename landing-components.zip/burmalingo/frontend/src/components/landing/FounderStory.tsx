export default function FounderStory() {
  return (
    <div className="bg-gold-pale border-y border-border py-18 px-7">
      <div className="max-w-2xl mx-auto text-center">
        <div className="text-gold text-2xl mb-5">✦</div>
        <h2 className="font-serif text-3xl font-bold text-bark leading-snug mb-6">
          "I know what worked.<br />
          <span className="text-forest-mid italic">And what was a waste of time."</span>
        </h2>
        <p className="text-bark-mid text-sm leading-relaxed mb-4">
          I started with self-study to save money, then enrolled in Zoom classes — then did
          both self-study and Zoom classes specifically for IELTS (all 4 skills). My reading
          and writing improved steadily, but my speaking only became real after I moved to
          the US in 2023 and had no choice but to use English every single day.
        </p>
        <p className="text-bark-mid text-sm leading-relaxed mb-4">
          Three years of living in an English environment later, I can tell you exactly which
          methods work at each stage and which ones don't. That's what BurmaLingo is built
          from — not theory, not translated content, but the actual path.
        </p>
        <p className="text-bark-mid text-sm leading-relaxed">
          Duolingo technically has English for Burmese speakers, but it is extremely thin —
          a handful of basic lessons with no depth, no IELTS preparation, and explanations
          that assume you already understand English. BurmaLingo is built entirely around
          the Burmese learner, with the specific grammar gaps and vocabulary needs that come
          from lived experience inside this problem.
        </p>
      </div>
    </div>
  )
}

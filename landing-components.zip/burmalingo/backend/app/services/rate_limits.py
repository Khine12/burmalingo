# Single source of truth for all free tier rate limits.
# All limits are enforced server-side in FastAPI only.
# Frontend limits are NEVER trusted.

from enum import Enum

class FeatureType(str, Enum):
    VOCAB        = "vocab"
    READING      = "reading"
    TRANSLATION  = "translation"
    WRITING      = "writing"
    LISTENING    = "listening"
    SPEAKING     = "speaking"

# (limit, period_days)
FREE_LIMITS: dict[FeatureType, tuple[int, int]] = {
    FeatureType.VOCAB:       (10, 7),   # 10 cards per week
    FeatureType.READING:     (3,  14),  # 3 passages per 2 weeks
    FeatureType.TRANSLATION: (3,  7),   # 3 exercises per week
    FeatureType.WRITING:     (3,  14),  # 3 submissions per 2 weeks
    FeatureType.LISTENING:   (3,  14),  # 3 exercises per 2 weeks
    FeatureType.SPEAKING:    (0,  1),   # paid only — 0 always
}

# Features where free users can submit but feedback is locked
FEEDBACK_LOCKED_FOR_FREE = {
    FeatureType.WRITING,
    FeatureType.TRANSLATION,
}

# Features completely blocked for free users
PAID_ONLY = {
    FeatureType.SPEAKING,
}
